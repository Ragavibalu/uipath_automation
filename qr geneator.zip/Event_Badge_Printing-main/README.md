# Event_Badge_Printing
UIpath StudioX

Create an event check-in system using QR codes.
Generate QR codes for event attendees and use UiPath StudioX to scan the codes upon arrival. 
The system can then automatically print personalized event badges for attendees.
